export default {base:'./'}
